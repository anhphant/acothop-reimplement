 Results and solutions downloaded at 

 https://bit.ly/3ayvWoQ (accessed on August 2, 2020)